﻿IT-Index Starter Kit

Unzip this file. It contains an empty folder named local-data.

Usage:
1. Extract this zip anywhere
2. Open the app, go to Settings -> Local Data -> Select Folder
3. In the dialog, find and select this local-data folder
   (search for local-data in File Explorer if needed)
